<?php
// Haetaan config.php:n sisältö ja asetustiedosto
// __DIR__ -vakiolla polku on aina oikea riippumatta mistä tiedostoa kutsutaan
require_once __DIR__ . '/../includes/config.php';

// Luodaan tietokantayhteys käyttäen config.php:n vakioita
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Tarkistetaan yhteys
if ($conn->connect_error) {
    die("Yhteys epäonnistui: " . $conn->connect_error);
}

// Asetetaan utf8mb4 charset
$conn->set_charset("utf8mb4");
?>
